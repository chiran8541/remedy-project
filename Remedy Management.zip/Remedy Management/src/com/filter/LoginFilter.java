package com.filter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.adminDAO;
import com.DAO.adminDAOImpl;
import com.doa.OrclDatabase;

public class LoginFilter implements Filter{

	@Override
	public void destroy() {
		
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		String username = (String)req.getParameter("username");
		String password = (String)req.getParameter("password");
		
		
		try
		{
			Connection con = OrclDatabase.getConnection();
			String query = "select * from users";
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ResultSet rs = ps.executeQuery(); 
			
			
			while(rs.next())
			{
				if(username.equals(rs.getString(5)) && password.equals(rs.getString(6)))
				{
					chain.doFilter(req, res);
				}
				
			}
			
			
			RequestDispatcher rd = req.getRequestDispatcher("index.jsp?msg=Invalid Username or Password!");
			rd.include(req, res);
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
		
	}
	
}
