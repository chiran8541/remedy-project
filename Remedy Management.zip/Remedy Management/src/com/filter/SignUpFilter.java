package com.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.doa.OrclDatabase;
import com.models.User;
import com.service.Service;

public class SignUpFilter implements Filter
{
	@Override
	public void destroy() 
	{
	}
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException 
	{
		int userId = 1;
		boolean found = false;
		boolean mobileno = false;
		try
		{
			int temp_id = 0;
			Connection con = OrclDatabase.getConnection();
			String query = "select * from users";
			PreparedStatement ps = con.prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			
			ResultSet rs = ps.executeQuery();
			String s = req.getParameter("e_mail");
			String mobile1 = req.getParameter("mobile");
			while(rs.next())
			{
				if(rs.getString(5).equals(s))
				{
					found = true;
					break;
				}
			}
			
			rs = ps.executeQuery();
			
			while(rs.next())
			{
				if(rs.getString(4).equals(mobile1))
				{
					mobileno = true;
				}
			}
			
			if(mobileno)
			{
				RequestDispatcher rd = req.getRequestDispatcher("SignUp.jsp?errmsg=Mobile Number exists!");
				rd.include(req, res);
			}
			else
			{
				if(!found)
				{
					
					String fname = req.getParameter("fname");
					String lname = req.getParameter("lname");
					String mobile = req.getParameter("mobile");
					String email = req.getParameter("e_mail");
					String password = req.getParameter("password");
					
					
					User u = new User(fname, lname, mobile, email, password);
					Service.addUser(u);
					
					req.getRequestDispatcher("index.jsp?msg=Account Created successfully. Please Login").forward(req, res);
				}
				else
				{
					RequestDispatcher rd = req.getRequestDispatcher("SignUp.jsp?errmsg=User Already Exists!");
					rd.include(req, res);
				}
			}
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	@Override
	public void init(FilterConfig arg0) throws ServletException 
	{
		
	}
}
